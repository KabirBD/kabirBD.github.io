# NSU-EduHub
NSU EduHub: a program designed to assist NSUers with some essential tools like CGPA calculators, course navigations, class schedules, mathematical problem solvers, converters, helpline and more.
